package com.binh.lab1;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;



@RestController

@RequestMapping("/lab1/users")
public class UserController {

    @GetMapping
    public User getUser() {
        return User.builder().username("Cabantac").password("binh1234").build();
    }
    
}
 