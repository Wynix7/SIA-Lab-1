package com.binh.lab1;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Builder
@AllArgsConstructor
@Data


public class User {

    private int uID;
    private String username;
    private String password;
    private boolean enabled;

}
